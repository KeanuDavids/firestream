@echo off
echo ========================================
echo   King Kong Build USB Installer
echo ========================================
echo.
echo This will create a ZIP file called "KingKongBuild_USB.zip"
echo that you can copy to a USB stick.
echo.
echo Instructions:
echo 1. Copy this ZIP to your USB stick
echo 2. Plug USB into your Kodi device
echo 3. Browse USB in Kodi and extract ZIP to:
echo    %APPDATA%\Kodi\userdata\
echo 4. Restart Kodi
echo 5. Go to Programs > King Kong Wizard > Builds
echo.
pause

REM Create the ZIP file with correct folder structure
powershell -Command "Compress-Archive -Path '..\addons\plugin.program.openwizard','My_Builds' -DestinationPath 'KingKongBuild_USB.zip' -Force"

echo.
echo Done! Created: KingKongBuild_USB.zip
echo Copy this file to your USB stick.
pause
