# King Kong Custom Kodi Build - USB Install Guide

## EASIEST WAY - USB Stick Install

### Step 1: Create the ZIP File

On your computer, right-click these TWO folders and select "Send to > Compressed (zip)":
1. The `addons` folder (find the one containing plugin.program.openwizard)
2. The `My_Builds` folder

Name the ZIP: `KingKongBuild.zip`

### Step 2: Copy to USB

Copy the ZIP to your USB stick.

### Step 3: Install on Kodi Device

1. Plug USB into your Kodi device
2. Open Kodi → Settings → File Manager
3. Add Source → Browse → USB
4. Select the ZIP file
5. Choose "Extract to: %APPDATA%\Kodi\userdata\"
6. Wait for extraction to complete

### Step 4: Restart & Install

1. Close Kodi completely (Force Stop)
2. Open Kodi again
3. Go to **Programs** → **King Kong Wizard**
4. Click **Builds**
5. Select **King Kong Custom Build**
6. Click **Install**

DONE!

## What's Included

- Titan Bingie Mod skin
- Firestream, TMDB Helper, YouTube
- Pre-configured settings
- Your saved sources and preferences

## Files

- `King+Kong+Build.zip` (~329MB) - Full backup
- `King+Kong+Build_guisettings.zip` (~20KB) - Just settings
