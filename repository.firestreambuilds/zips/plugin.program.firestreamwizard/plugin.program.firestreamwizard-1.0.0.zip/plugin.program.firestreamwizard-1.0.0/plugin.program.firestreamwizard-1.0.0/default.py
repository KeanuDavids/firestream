################################################################################
#      Copyright (C) 2019 drinfernoo                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################


if __name__ == '__main__':
    import sys
    import xbmcaddon
    import xbmcgui
    import os
    
    # Check for first run - show clean install dialog
    ADDON_ID = 'plugin.program.openwizard'
    ADDON = xbmcaddon.Addon(ADDON_ID)
    PROFILE = ADDON.getAddonInfo('profile')
    PATH = ADDON.getAddonInfo('path')
    FIRST_RUN_FILE = os.path.join(PROFILE, 'first_run_done')
    
    if not os.path.exists(FIRST_RUN_FILE):
        # First run - show dialog
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno(
            'King Kong Wizard',
            'This will perform a CLEAN INSTALL.\\n\\nAll existing Kodi data will be deleted.\\n\\nDo you want to continue?'
        )
        if ret:
            # User chose YES - do clean install
            from resources.libs.common import tools
            tools.wipe()
            
            # Copy My_Builds from addon resources to userdata
            import shutil
            source_builds = os.path.join(PATH, 'resources', 'My_Builds')
            dest_builds = os.path.join(os.path.expanduser('~'), 'AppData', 'Roaming', 'Kodi', 'userdata', 'My_Builds')
            if os.path.exists(source_builds):
                if os.path.exists(dest_builds):
                    shutil.rmtree(dest_builds)
                shutil.copytree(source_builds, dest_builds)
        else:
            # User chose NO - skip wipe
            pass
        
        # Mark first run as done
        with open(FIRST_RUN_FILE, 'w') as f:
            f.write('done')
    
    from resources.libs.common import router

    _handle = int(sys.argv[1])
    _params = sys.argv[2][1:]
    
    dispatcher = router.Router()
    dispatcher.dispatch(_handle, _params)
